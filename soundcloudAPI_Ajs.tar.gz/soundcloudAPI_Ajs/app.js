//var sounder = angular.module('sounder', ['']);  

var app = angular.module('sounds', []);